package com.serob.gptbuddy;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

@Mod(GPTBuddy.MOD_ID)
public class GPTBuddy {
    public static final String MOD_ID = "gptbuddy";

    public GPTBuddy() { MinecraftForge.EVENT_BUS.register(this); }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("gptbuddy")
            .then(Commands.literal("summon").executes(ctx -> {
                ServerPlayer player = ctx.getSource().getPlayerOrException();
                Level level = player.level();
                Wolf buddy = EntityType.WOLF.create(level);
                if (buddy == null) return 0;
                Vec3 p = player.position();
                buddy.moveTo(p.x + 1.5, p.y, p.z, player.getYRot(), 0);
                buddy.setTame(true);
                buddy.setOwnerUUID(player.getUUID());
                buddy.setPersistenceRequired();
                buddy.setCustomName(Component.literal("GPT Buddy"));
                buddy.setCustomNameVisible(true);
                level.addFreshEntity(buddy);
                ctx.getSource().sendSuccess(() -> Component.literal("GPT Buddy: Я здесь! Буду следовать за тобой."), false);
                return 1;
            }))
            .then(Commands.literal("help").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal("Команды: /gptbuddy summon — призвать компаньона; /gptbuddy help — помощь."), false);
                return 1;
            }))
            .executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal("Используй /gptbuddy summon или /gptbuddy help."), false);
                return 1;
            })
        );
    }

    @SubscribeEvent
    public void onChat(ServerChatEvent event) {
        String message = event.getMessage().getString().toLowerCase(java.util.Locale.ROOT).trim();
        String answer = reply(message);
        if (answer != null) {
            ServerPlayer player = event.getPlayer();
            player.sendSystemMessage(Component.literal("[GPT Buddy] " + answer));
        }
    }

    private static String reply(String text) {
        if (text.contains("привет") || text.contains("здравствуй")) return "Привет! Рад тебя видеть!";
        if (text.contains("как дела")) return "У меня всё отлично. Куда отправимся?";
        if (text.contains("кто ты")) return "Я GPT Buddy — твой игровой компаньон.";
        if (text.contains("следуй") || text.contains("иди за мной")) return "Если ты призвал меня командой /gptbuddy summon, я уже рядом!";
        if (text.contains("помощь") || text.equals("/help")) return "Напиши «привет», «как дела» или используй /gptbuddy help.";
        if (text.contains("спасибо")) return "Всегда пожалуйста!";
        if (text.contains("пока")) return "До встречи! Удачи в приключении!";
        return null;
    }
}
