package com.example.gptbuddy;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.StringArgumentType;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

@Mod(GptBuddyMod.MOD_ID)
public class GptBuddyMod {
    public static final String MOD_ID = "gptbuddy";

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .build();

    public GptBuddyMod() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void registerCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
            Commands.literal("gpt")
                .then(Commands.argument("message", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        askAI(ctx.getSource(),
                            StringArgumentType.getString(ctx, "message"));
                        return 1;
                    })
                )
        );
    }

    private static void askAI(net.minecraft.commands.CommandSourceStack source,
                              String prompt) {
        String key = System.getenv("OPENAI_API_KEY");
        if (key == null || key.isBlank()) {
            source.sendFailure(Component.literal(
                "GPT Buddy: OPENAI_API_KEY is not configured on the game/server process."));
            return;
        }

        source.sendSuccess(() -> Component.literal("[GPT Buddy] Thinking..."), false);

        JsonObject body = new JsonObject();
        // Change this to a model available to your OpenAI API project.
        body.addProperty("model", "gpt-4.1-mini");
        body.addProperty("instructions",
            "You are a friendly Minecraft companion. Reply in Russian, briefly and helpfully. " +
            "Do not claim you can see the game world unless the player provides details.");
        body.addProperty("input", prompt);
        body.addProperty("max_output_tokens", 250);

        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create("https://api.openai.com/v1/responses"))
            .timeout(Duration.ofSeconds(60))
            .header("Authorization", "Bearer " + key)
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
            .build();

        MinecraftServer server = source.getServer();

        HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
            .orTimeout(65, TimeUnit.SECONDS)
            .whenComplete((response, error) -> server.execute(() -> {
                if (error != null) {
                    source.sendFailure(Component.literal(
                        "GPT Buddy: connection failed or timed out."));
                    return;
                }
                if (response.statusCode() < 200 || response.statusCode() >= 300) {
                    source.sendFailure(Component.literal(
                        "GPT Buddy: API HTTP " + response.statusCode() +
                        ". Check API key, model access, and billing."));
                    return;
                }
                try {
                    JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                    String answer = extractText(json);
                    if (answer.isBlank()) answer = "The model returned no text.";
                    if (answer.length() > 2000) answer = answer.substring(0, 2000) + "...";
                    String finalAnswer = answer;
                    source.sendSuccess(() -> Component.literal("[GPT Buddy] " + finalAnswer), false);
                } catch (Exception ex) {
                    source.sendFailure(Component.literal(
                        "GPT Buddy: could not parse the API response."));
                }
            }));
    }

    private static String extractText(JsonObject json) {
        StringBuilder result = new StringBuilder();
        JsonArray output = json.getAsJsonArray("output");
        if (output == null) return "";
        for (JsonElement item : output) {
            if (!item.isJsonObject()) continue;
            JsonArray content = item.getAsJsonObject().getAsJsonArray("content");
            if (content == null) continue;
            for (JsonElement part : content) {
                if (!part.isJsonObject()) continue;
                JsonObject obj = part.getAsJsonObject();
                if (obj.has("type") && "output_text".equals(obj.get("type").getAsString())
                        && obj.has("text")) {
                    if (result.length() > 0) result.append('\n');
                    result.append(obj.get("text").getAsString());
                }
            }
        }
        return result.toString();
    }
}
